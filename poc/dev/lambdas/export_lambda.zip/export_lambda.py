import os
import json
import boto3

rds = boto3.client("rds")

ARCHIVE_BUCKET  = os.environ["ARCHIVE_BUCKET"]
EXPORT_ROLE_ARN = os.environ["EXPORT_ROLE_ARN"]
KMS_KEY_ARN     = os.environ["KMS_KEY_ARN"]

def handler(event, context):
    # event: {"snapshot_identifier": "...", "snapshot_arn": "..."}
    if isinstance(event, str):
        event = json.loads(event)

    snapshot_id  = event["snapshot_identifier"]
    snapshot_arn = event["snapshot_arn"]

    export_id = f"export-{snapshot_id}"
    s3_prefix = f"snapshots/{snapshot_id}"

    resp = rds.start_export_task(
        ExportTaskIdentifier=export_id,
        SourceArn=snapshot_arn,
        S3Bucket=ARCHIVE_BUCKET,
        S3Prefix=s3_prefix,
        IamRoleArn=EXPORT_ROLE_ARN,
        KmsKeyId=KMS_KEY_ARN
    )

    return {
        "export_task_identifier": resp["ExportTaskIdentifier"],
        "snapshot_identifier": snapshot_id,
        "s3_prefix": s3_prefix
    }
