import os
import boto3
from datetime import datetime, timezone, timedelta

rds = boto3.client("rds")
lambda_client = boto3.client("lambda")

RETENTION_DAYS = int(os.environ.get("RETENTION_DAYS", "1"))
EXPORT_LAMBDA_ARN = os.environ["EXPORT_LAMBDA_ARN"]

def handler(event, context):
    cutoff = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)
    snapshots = []

    paginator = rds.get_paginator("describe_db_snapshots")
    for page in paginator.paginate(SnapshotType="manual"):
        for snap in page["DBSnapshots"]:
            if snap["Status"] != "available":
                continue
            if snap["SnapshotCreateTime"] > cutoff:
                continue
            snapshots.append({
                "DBSnapshotIdentifier": snap["DBSnapshotIdentifier"],
                "DBSnapshotArn": snap["DBSnapshotArn"]
            })

    for snap in snapshots:
        payload = {
            "snapshot_identifier": snap["DBSnapshotIdentifier"],
            "snapshot_arn": snap["DBSnapshotArn"]
        }
        lambda_client.invoke(
            FunctionName=EXPORT_LAMBDA_ARN,
            InvocationType="Event",
            Payload=bytes(str(payload), "utf-8")
        )

    return {"processed_snapshots": [s["DBSnapshotIdentifier"] for s in snapshots]}
