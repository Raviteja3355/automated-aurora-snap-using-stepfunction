import os
import json
import urllib.request
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timezone, timedelta

rds           = boto3.client("rds")
backup_client = boto3.client("backup")
s3            = boto3.client("s3")
dynamodb      = boto3.resource("dynamodb")

BUCKET_NAME       = os.environ["BUCKET_NAME"]
BACKUP_VAULT_NAME = os.environ["BACKUP_VAULT_NAME"]
DRY_RUN_MODE      = os.environ.get("DRY_RUN_MODE", "false").lower() == "true"

DELETE_SOURCE_AFTER_EXPORT = os.environ.get("DELETE_SOURCE_AFTER_EXPORT", "false").lower() == "true"
DELETE_DELAY_DAYS          = int(os.environ.get("DELETE_DELAY_DAYS", "7"))

EXPORT_TASK_LOOKBACK_DAYS = int(os.environ.get("EXPORT_TASK_LOOKBACK_DAYS", "90"))

PROCESSED_TASKS_TABLE = os.environ.get("PROCESSED_TASKS_TABLE", "")

# Google Chat space webhook URLs.
# In Google Chat: open a Space → Manage webhooks → Add webhook → copy the URL.
# Leave any URL empty to disable that notification channel.
GOOGLE_CHAT_SUCCESS_WEBHOOK_URL          = os.environ.get("GOOGLE_CHAT_SUCCESS_WEBHOOK_URL", "")
GOOGLE_CHAT_FAILURE_WEBHOOK_URL          = os.environ.get("GOOGLE_CHAT_FAILURE_WEBHOOK_URL", "")
GOOGLE_CHAT_PENDING_DELETION_WEBHOOK_URL = os.environ.get("GOOGLE_CHAT_PENDING_DELETION_WEBHOOK_URL", "")
GOOGLE_CHAT_DELETED_WEBHOOK_URL          = os.environ.get("GOOGLE_CHAT_DELETED_WEBHOOK_URL", "")


# ---------------------------------------------------------------------------
# State tracking
# DynamoDB keys:
#   export:{export_id}   — task fully resolved (no further processing)
#   notif:{export_id}    — success / integrity-failure notification already sent
#   pending:{export_id}  — pending-deletion notification already sent
# ---------------------------------------------------------------------------

def _is_task_processed(key):
    if not PROCESSED_TASKS_TABLE:
        return False
    table = dynamodb.Table(PROCESSED_TASKS_TABLE)
    return "Item" in table.get_item(Key={"task_id": key})


def _mark_task_processed(key):
    if not PROCESSED_TASKS_TABLE or DRY_RUN_MODE:
        return
    table = dynamodb.Table(PROCESSED_TASKS_TABLE)
    ttl   = int((datetime.now(timezone.utc) + timedelta(days=90)).timestamp())
    table.put_item(Item={
        "task_id":      key,
        "ttl":          ttl,
        "processed_at": datetime.now(timezone.utc).isoformat()
    })


# ---------------------------------------------------------------------------
# ARN helpers
# ---------------------------------------------------------------------------

def _is_cluster_snapshot(snapshot_arn):
    return ":cluster-snapshot:" in snapshot_arn


def _is_backup_recovery_point(snapshot_arn):
    """
    Return True if this snapshot was created by AWS Backup.
    Backup recovery point ARNs contain 'awsbackup' in the last segment:
    e.g. arn:aws:rds:...:snapshot:awsbackup-job-20240101t000000-abc123
    """
    return "awsbackup" in snapshot_arn.split(":")[-1].lower()


def _extract_snapshot_id(snapshot_arn):
    if _is_cluster_snapshot(snapshot_arn):
        return snapshot_arn.split(":cluster-snapshot:")[-1]
    return snapshot_arn.split(":snapshot:")[-1]


def _source_type_label(snapshot_arn):
    if _is_backup_recovery_point(snapshot_arn):
        return "backup_recovery_point"
    if _is_cluster_snapshot(snapshot_arn):
        return "rds_cluster_snapshot"
    return "rds_instance_snapshot"


# ---------------------------------------------------------------------------
# Export task listing — scoped to this pipeline's bucket and time window
# ---------------------------------------------------------------------------

def list_export_tasks():
    tasks           = []
    lookback_cutoff = datetime.now(timezone.utc) - timedelta(days=EXPORT_TASK_LOOKBACK_DAYS)
    paginator       = rds.get_paginator("describe_export_tasks")

    for page in paginator.paginate():
        for task in page["ExportTasks"]:
            if task.get("S3Bucket") != BUCKET_NAME:
                continue
            task_start_time = task.get("TaskStartTime")
            if task_start_time:
                if task_start_time.tzinfo is None:
                    task_start_time = task_start_time.replace(tzinfo=timezone.utc)
                if task_start_time < lookback_cutoff:
                    continue
            tasks.append(task)

    return tasks


# ---------------------------------------------------------------------------
# S3 integrity helpers
# ---------------------------------------------------------------------------

def get_s3_objects(prefix):
    objs      = []
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=BUCKET_NAME, Prefix=prefix):
        for obj in page.get("Contents", []):
            objs.append(obj)
    return objs


def load_json_object(key):
    resp = s3.get_object(Bucket=BUCKET_NAME, Key=key)
    body = resp["Body"].read()
    if len(body) == 0:
        raise ValueError(f"Empty JSON file: {key}")
    return json.loads(body)


def check_integrity_for_export(task):
    snapshot_arn = task["SourceArn"]
    snapshot_id  = _extract_snapshot_id(snapshot_arn)
    prefix       = f"snapshots/{snapshot_id}/"
    objs         = get_s3_objects(prefix)

    if not objs:
        raise ValueError(f"No objects found under prefix {prefix}")

    keys       = [o["Key"] for o in objs]
    info_key   = next((k for k in keys if "export_info_" in k and k.endswith(".json")), None)
    tables_key = next((k for k in keys if "export_tables_info_" in k and k.endswith(".json")), None)

    if not info_key:
        raise ValueError(f"export_info json not found under {prefix}")
    if not tables_key:
        raise ValueError(f"export_tables_info json not found under {prefix}")

    info_json   = load_json_object(info_key)
    tables_json = load_json_object(tables_key)

    if "SourceArn" not in info_json and "sourceArn" not in info_json:
        raise ValueError("export_info json missing SourceArn/sourceArn")
    if not isinstance(tables_json, (dict, list)):
        raise ValueError("export_tables_info json has unexpected structure")

    return {"info_key": info_key, "tables_key": tables_key}


# ---------------------------------------------------------------------------
# Deletion — routes to correct API based on snapshot origin
# Returns dict: { outcome: "deleted" | "pending" | "skipped", ...extra }
# ---------------------------------------------------------------------------

def maybe_delete_snapshot(snapshot_arn, task_end_time):
    if not DELETE_SOURCE_AFTER_EXPORT:
        return {"outcome": "skipped", "reason": "flag_disabled"}
    if task_end_time is None:
        return {"outcome": "skipped", "reason": "no_end_time"}

    if task_end_time.tzinfo is None:
        task_end_time = task_end_time.replace(tzinfo=timezone.utc)

    elapsed        = datetime.now(timezone.utc) - task_end_time
    scheduled_date = task_end_time + timedelta(days=DELETE_DELAY_DAYS)

    if elapsed < timedelta(days=DELETE_DELAY_DAYS):
        remaining = DELETE_DELAY_DAYS - elapsed.days
        return {
            "outcome":                 "pending",
            "days_remaining":          remaining,
            "scheduled_deletion_date": scheduled_date.isoformat(),
        }

    if DRY_RUN_MODE:
        print(f"[DRY RUN] Would delete {snapshot_arn}")
        return {"outcome": "skipped", "reason": "dry_run"}

    try:
        if _is_backup_recovery_point(snapshot_arn):
            backup_client.delete_recovery_point(
                BackupVaultName=BACKUP_VAULT_NAME,
                RecoveryPointArn=snapshot_arn
            )
        elif _is_cluster_snapshot(snapshot_arn):
            snapshot_id = _extract_snapshot_id(snapshot_arn)
            rds.delete_db_cluster_snapshot(DBClusterSnapshotIdentifier=snapshot_id)
        else:
            snapshot_id = _extract_snapshot_id(snapshot_arn)
            rds.delete_db_snapshot(DBSnapshotIdentifier=snapshot_id)

        return {
            "outcome":     "deleted",
            "deleted_at":  datetime.now(timezone.utc).isoformat(),
            "source_type": _source_type_label(snapshot_arn),
        }
    except ClientError:
        raise


# ---------------------------------------------------------------------------
# Google Chat notification helpers
# Google Chat spaces webhook format: POST {"text": "..."}
# Markdown supported: *bold*, _italic_, `code`, newlines with \n
# ---------------------------------------------------------------------------

def _post_to_google_chat(webhook_url, text):
    """
    POST a plain-text message to a Google Chat space via incoming webhook.
    No-op when webhook_url is empty.
    """
    if not webhook_url:
        return
    payload = json.dumps({"text": text}).encode("utf-8")
    req = urllib.request.Request(
        webhook_url,
        data=payload,
        headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=5):
            pass
    except Exception as e:
        print(f"Google Chat notification failed: {e}")


def notify_success(export_id, snapshot_arn, task, integrity):
    """Post to the success space when an export completes and passes integrity."""
    snapshot_id = _extract_snapshot_id(snapshot_arn)
    source_type = _source_type_label(snapshot_arn)
    task_start  = task.get("TaskStartTime", "N/A")
    task_end    = task.get("TaskEndTime", "N/A")

    text = (
        "*Export Successful* ✅\n"
        f"*Export Task:* `{export_id}`\n"
        f"*Snapshot ID:* `{snapshot_id}`\n"
        f"*Source Type:* {source_type}\n"
        f"*Started:* {task_start}\n"
        f"*Completed:* {task_end}\n"
        f"*S3 Bucket:* {BUCKET_NAME}\n"
        f"*Integrity Files:*\n"
        f"  • `{integrity['info_key']}`\n"
        f"  • `{integrity['tables_key']}`"
    )
    _post_to_google_chat(GOOGLE_CHAT_SUCCESS_WEBHOOK_URL, text)


def notify_failure(export_id, snapshot_arn, status, error=None):
    """Post to the failure space for FAILED, CANCELED, or integrity errors."""
    snapshot_id = _extract_snapshot_id(snapshot_arn)

    text = (
        "*Export Failed* ❌\n"
        f"*Export Task:* `{export_id}`\n"
        f"*Snapshot ID:* `{snapshot_id}`\n"
        f"*Status:* {status}"
    )
    if error:
        text += f"\n*Error:* {error}"

    _post_to_google_chat(GOOGLE_CHAT_FAILURE_WEBHOOK_URL, text)


def notify_pending_deletion(export_id, snapshot_arn, deletion_info):
    """
    Post to the pending-deletion space once per task when the delay window
    has not yet elapsed. Shows the exact scheduled deletion date.
    """
    snapshot_id      = _extract_snapshot_id(snapshot_arn)
    source_type      = _source_type_label(snapshot_arn)
    days_remaining   = deletion_info["days_remaining"]
    scheduled_date   = deletion_info["scheduled_deletion_date"]

    text = (
        "*Snapshot Deletion Scheduled* 🗓️\n"
        f"*Snapshot ID:* `{snapshot_id}`\n"
        f"*Source Type:* {source_type}\n"
        f"*Export Task:* `{export_id}`\n"
        f"*Days Remaining:* {days_remaining} day(s)\n"
        f"*Scheduled Deletion Date:* {scheduled_date}\n"
        f"*Configured Delay:* {DELETE_DELAY_DAYS} days"
    )
    _post_to_google_chat(GOOGLE_CHAT_PENDING_DELETION_WEBHOOK_URL, text)


def notify_deleted(export_id, snapshot_arn, deletion_info):
    """Post to the deleted space after a snapshot is successfully removed."""
    snapshot_id = _extract_snapshot_id(snapshot_arn)

    text = (
        "*Snapshot Deleted* 🗑️\n"
        f"*Snapshot ID:* `{snapshot_id}`\n"
        f"*Source Type:* {deletion_info['source_type']}\n"
        f"*Export Task:* `{export_id}`\n"
        f"*Deleted At:* {deletion_info['deleted_at']}"
    )
    _post_to_google_chat(GOOGLE_CHAT_DELETED_WEBHOOK_URL, text)


# ---------------------------------------------------------------------------
# Main handler
# ---------------------------------------------------------------------------

def handler(event, context):
    tasks   = list_export_tasks()
    results = []

    for task in tasks:
        status        = task["Status"]
        export_id     = task["ExportTaskIdentifier"]
        snapshot_arn  = task["SourceArn"]
        task_end_time = task.get("TaskEndTime")

        terminal_key = f"export:{export_id}"   # set when task is fully resolved
        notif_key    = f"notif:{export_id}"    # set after success/failure notification
        pending_key  = f"pending:{export_id}"  # set after pending-deletion notification

        if status == "COMPLETE":
            if _is_task_processed(terminal_key):
                continue

            # --- Integrity check ---
            try:
                integrity = check_integrity_for_export(task)
            except Exception as e:
                if not _is_task_processed(notif_key):
                    notify_failure(export_id, snapshot_arn, "INTEGRITY_FAILED", error=str(e))
                    _mark_task_processed(notif_key)
                _mark_task_processed(terminal_key)
                results.append({"export_task": export_id, "status": "INTEGRITY_FAILED", "error": str(e)})
                continue

            # --- Success notification (send once) ---
            if not _is_task_processed(notif_key):
                notify_success(export_id, snapshot_arn, task, integrity)
                _mark_task_processed(notif_key)

            # --- Deletion ---
            deletion_result = maybe_delete_snapshot(snapshot_arn, task_end_time)
            outcome = deletion_result["outcome"]

            if outcome == "pending":
                if not _is_task_processed(pending_key):
                    notify_pending_deletion(export_id, snapshot_arn, deletion_result)
                    _mark_task_processed(pending_key)
                results.append({
                    "export_task":    export_id,
                    "status":         "OK",
                    "deletion":       "pending",
                    "days_remaining": deletion_result["days_remaining"],
                })

            elif outcome == "deleted":
                notify_deleted(export_id, snapshot_arn, deletion_result)
                _mark_task_processed(terminal_key)
                results.append({"export_task": export_id, "status": "OK", "deletion": "deleted"})

            else:
                # skipped: flag_disabled | dry_run | no_end_time
                _mark_task_processed(terminal_key)
                results.append({
                    "export_task": export_id,
                    "status":      "OK",
                    "deletion":    f"skipped:{deletion_result.get('reason', '')}",
                })

        elif status in ("FAILED", "CANCELED"):
            if _is_task_processed(terminal_key):
                continue
            notify_failure(export_id, snapshot_arn, status)
            _mark_task_processed(terminal_key)
            results.append({"export_task": export_id, "status": status})

    return {"results": results}
