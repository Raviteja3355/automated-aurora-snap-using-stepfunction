import os
import re
import json
import random
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timezone, timedelta

rds           = boto3.client("rds")
lambda_client = boto3.client("lambda")

RETENTION_DAYS         = int(os.environ.get("RETENTION_DAYS", "730"))
EXPORT_LAMBDA_ARN      = os.environ["EXPORT_LAMBDA_ARN"]
ARCHIVE_BUCKET         = os.environ["ARCHIVE_BUCKET"]
DRY_RUN_MODE           = os.environ.get("DRY_RUN_MODE", "false").lower() == "true"
MAX_EXPORT_CONCURRENCY = int(os.environ.get("MAX_EXPORT_CONCURRENCY", "5"))

TARGET_CLUSTER_IDENTIFIERS = [
    c.strip()
    for c in os.environ.get("TARGET_CLUSTER_IDENTIFIERS", "").split(",")
    if c.strip()
]
SNAPSHOT_NAME_PATTERN = os.environ.get("SNAPSHOT_NAME_PATTERN", "")


def _count_in_progress_exports():
    """
    Count export tasks currently running for this pipeline's S3 bucket.
    Used to avoid exceeding the RDS per-account concurrent export limit.
    """
    count     = 0
    paginator = rds.get_paginator("describe_export_tasks")
    for page in paginator.paginate():
        for task in page["ExportTasks"]:
            if task.get("S3Bucket") == ARCHIVE_BUCKET and task["Status"] in ("STARTING", "IN_PROGRESS"):
                count += 1
    return count


def _list_manual_snapshots(cutoff):
    """
    List eligible manual snapshots — both RDS instance and Aurora cluster —
    that have aged past the retention threshold and are ready for export.
    """
    eligible = []

    # --- RDS instance manual snapshots ---
    paginator = rds.get_paginator("describe_db_snapshots")
    for page in paginator.paginate(SnapshotType="manual"):
        for snap in page["DBSnapshots"]:
            if snap.get("Status") != "available":
                continue

            creation_time = snap["SnapshotCreateTime"]
            if creation_time.tzinfo is None:
                creation_time = creation_time.replace(tzinfo=timezone.utc)
            if creation_time > cutoff:
                continue

            snapshot_id  = snap["DBSnapshotIdentifier"]
            snapshot_arn = snap["DBSnapshotArn"]

            if TARGET_CLUSTER_IDENTIFIERS:
                if snap["DBInstanceIdentifier"] not in TARGET_CLUSTER_IDENTIFIERS:
                    continue

            if SNAPSHOT_NAME_PATTERN:
                if not re.search(SNAPSHOT_NAME_PATTERN, snapshot_id):
                    continue

            eligible.append({
                "DBSnapshotIdentifier": snapshot_id,
                "DBSnapshotArn":        snapshot_arn,
            })

    # --- Aurora cluster manual snapshots ---
    paginator = rds.get_paginator("describe_db_cluster_snapshots")
    for page in paginator.paginate(SnapshotType="manual"):
        for snap in page["DBClusterSnapshots"]:
            if snap.get("Status") != "available":
                continue

            creation_time = snap["SnapshotCreateTime"]
            if creation_time.tzinfo is None:
                creation_time = creation_time.replace(tzinfo=timezone.utc)
            if creation_time > cutoff:
                continue

            snapshot_id  = snap["DBClusterSnapshotIdentifier"]
            snapshot_arn = snap["DBClusterSnapshotArn"]

            if TARGET_CLUSTER_IDENTIFIERS:
                if snap["DBClusterIdentifier"] not in TARGET_CLUSTER_IDENTIFIERS:
                    continue

            if SNAPSHOT_NAME_PATTERN:
                if not re.search(SNAPSHOT_NAME_PATTERN, snapshot_id):
                    continue

            eligible.append({
                "DBSnapshotIdentifier": snapshot_id,
                "DBSnapshotArn":        snapshot_arn,
            })

    return eligible


def handler(event, context):
    cutoff   = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)
    eligible = _list_manual_snapshots(cutoff)

    # Shuffle so the same snapshots do not always consume the concurrency budget
    random.shuffle(eligible)

    if DRY_RUN_MODE:
        print(f"[DRY RUN] Would invoke export for {len(eligible)} snapshot(s)")
        return {
            "dry_run": True,
            "eligible_snapshots": [s["DBSnapshotIdentifier"] for s in eligible]
        }

    in_progress     = _count_in_progress_exports()
    available_slots = max(0, MAX_EXPORT_CONCURRENCY - in_progress)
    batch           = eligible[:available_slots]

    invoked = []
    errors  = []
    for snap in batch:
        payload = {
            "snapshot_identifier": snap["DBSnapshotIdentifier"],
            "snapshot_arn":        snap["DBSnapshotArn"],
        }
        try:
            lambda_client.invoke(
                FunctionName=EXPORT_LAMBDA_ARN,
                InvocationType="Event",
                Payload=json.dumps(payload)
            )
            invoked.append(snap["DBSnapshotIdentifier"])
        except ClientError as e:
            print(f"Failed to invoke export for {snap['DBSnapshotIdentifier']}: {e}")
            errors.append({"snapshot": snap["DBSnapshotIdentifier"], "error": str(e)})

    return {
        "eligible_count":    len(eligible),
        "in_progress_count": in_progress,
        "available_slots":   available_slots,
        "invoked_count":     len(invoked),
        "invoked_snapshots": invoked,
        "errors":            errors
    }
